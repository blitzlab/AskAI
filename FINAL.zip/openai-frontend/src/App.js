import React from 'react';
import OpenAIForm from './OpenAIForm';

function App() {
  return (
    <div className="App">
      <h1>OpenAI Answer Generator</h1>
      <OpenAIForm />
    </div>
  );
}

export default App;
