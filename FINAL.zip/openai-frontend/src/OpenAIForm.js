import React, { useState } from 'react';
import axios from 'axios';

const OpenAIForm = () => {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const response = await axios.post('/api/openai/', {
            text: inputText,
      });
      setOutputText(response.data.answer);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />
        <button type="submit">Send</button>
      </form>
      <div>
        <h3>Generated Answer:</h3>
        <p>{outputText}</p>
      </div>
    </div>
  );
};

export default OpenAIForm;
