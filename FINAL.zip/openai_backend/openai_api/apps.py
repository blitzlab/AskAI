from django.apps import AppConfig


class OpenaiApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'openai_api'
